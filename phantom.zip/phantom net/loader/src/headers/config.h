#pragma once

#define HTTP_SERVER "18.230.122.154"
#define HTTP_PORT 80

#define TFTP_SERVER "18.230.122.154"
